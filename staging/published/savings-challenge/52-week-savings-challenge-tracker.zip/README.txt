52-Week Savings Challenge Tracker
=================================

SETUP
1. Unzip this file.
2. Double-click index.html to open it in your browser (Chrome, Edge, Firefox, or Safari).
3. Bookmark it -- that bookmark IS the app. No internet needed after that.

YOUR DATA
- Your checkmarks are saved in your browser on this device only.
- It does not sync between devices and does not back itself up.
- Clearing your browser's data erases your progress. Private/incognito mode may not save it.
- On phones: open index.html from your browser (not a file-manager preview) and bookmark it there.

WHAT IT DOES
- Set any starting amount and weekly increase (classic $1 = $1,378 total).
- Check off each week as you save; running total and progress bar update live.
- Cumulative growth chart -- click any week dot to see that week's amount and total.
- Dark mode, sample data, sound effects (mutable).

No account. No subscription. No ads. No tracking.
